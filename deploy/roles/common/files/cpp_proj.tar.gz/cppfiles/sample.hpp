#ifndef XXXX_header_file
#define XXXX_header_file

class XXXX {
public:
    XXXX(); 
    ~XXXX();

   int getX();
   void setX(int); 

private:
    // copy-ctor is private so it can't be called and don't
    // want compiler to give me its version of the copy ctor.
    // Also disabling compiler to provide me an assignment.
    XXXX(const XXXX&);
    XXXX& operator=(const XXXX&);

    int x;
};

#endif
