/*
 * =====================================================================================
 *
 *       Filename:  sample.cpp
 *
 *    Description:  
 *
 *        Version:  1.0
 *        Created:  03/22/2014 23:00:25
 *       Revision:  none
 *       Compiler:  gcc
 *
 *         Author:  jjaffari (), jjaffari@cisco.com
 *   Organization:  
 *
 * =====================================================================================
 */

#include <iostream>
#include "sample.hpp"

XXXX::XXXX() : x(0) {}
XXXX::~XXXX()       {}

int XXXX::getX() {
    return x;
}

void XXXX::setX(int x_) {
    x = x_;
}

using namespace std;

int
main() {

    XXXX* c = new XXXX();
    cout << "My test x : "<< c->getX() << endl; 
}
