This is a placeholder for the CodeIgniter 3 User Guide.
